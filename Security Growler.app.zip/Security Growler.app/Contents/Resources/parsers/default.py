def parse(line, source=None):
    return (None, '', '')
